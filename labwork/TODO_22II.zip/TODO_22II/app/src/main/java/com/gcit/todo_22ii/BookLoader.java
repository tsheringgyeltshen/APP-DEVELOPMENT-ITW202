package com.gcit.todo_22ii;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.loader.content.AsyncTaskLoader;

import static android.net.wifi.WifiConfiguration.Status.strings;

public class BookLoader extends AsyncTaskLoader<String> {


    public BookLoader (Context context){
        super(context);
    }

    @Nullable

    @Override
    public String loadInBackground() {
        return NetworkUtils.getBookInfo(strings[0]);
    }

    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    private String mQueryString;

    BookLoader(Context context, String queryString) {
        super(context);
        mQueryString = queryString;
    }


}
